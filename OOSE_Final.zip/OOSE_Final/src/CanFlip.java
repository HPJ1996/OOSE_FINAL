
public interface CanFlip {
	public void flip();
}
