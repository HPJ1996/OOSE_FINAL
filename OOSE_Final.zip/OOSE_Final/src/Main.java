
public class Main {
	
	@SuppressWarnings("unused")
	public static void main(String args[]) {
		
		ChessGame chessGame = new ChessGame();
		System.out.println("Fuck you!!!");
	}

}
