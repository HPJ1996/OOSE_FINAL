
public interface CanRotate {
	public void rotate();
}
