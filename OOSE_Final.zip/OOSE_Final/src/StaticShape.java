
public class StaticShape {

	public static boolean[][] shape0 = {{false,true,true,true}, {true,true,false,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape1 = {{false,true,false,false}, {true,true,true,true}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape2 = {{true,true,false,false}, {true,true,false,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape3 = {{true,false,false,false}, {true,true,false,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape4 = {{true,false,false,false}, {true,false,false,false}, {true,true,true,false}, {false,false,false,false}};
	public static boolean[][] shape5 = {{true,true,true,true}, {false,false,false,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape6 = {{true,false,false,false}, {true,true,true,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape7 = {{true,true,false,false}, {true,true,true,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape8 = {{false,true,false,false}, {true,true,true,false}, {false,true,false,false}, {false,false,false,false}};
	public static boolean[][] shape9 = {{true,false,true,false}, {true,true,true,false}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape10 = {{true,false,false,false}, {true,true,true,true}, {false,false,false,false}, {false,false,false,false}};
	public static boolean[][] shape11 = {{true,false,false,false}, {true,true,false,false}, {false,true,true,false}, {false,false,false,false}};
}
